# MobSwords — Paper 1.21.10

A Maven plugin project for Paper servers. Every custom sword is a normal Netherite Sword with a custom name, lore, and persistent item tag.

## Build
Requires Java 21 and Maven.
1. Upload this folder to a GitHub repository or open it in GitHub Codespaces.
2. In the terminal, run: `mvn package`
3. The plugin JAR will be created at `target/mobswords-1.0.0.jar`.
4. Put that JAR in your Paper server's `plugins` folder and restart the server.

## Commands
- `/mobsword list`
- `/mobsword give <player> creeper`
- `/mobsword give <player> zombie`
- `/mobsword give <player> skeleton`
- `/mobsword give <player> enderman`
- `/mobsword give <player> blaze`

Giving swords requires OP by default (`mobswords.admin`). Listing is available to everyone.

## Abilities
- **Creeper:** 20% chance for a small blast that does not damage blocks.
- **Zombie:** chance to apply Weakness and Hunger; heals 2 health on a kill.
- **Skeleton:** chance for bonus damage and Slowness.
- **Enderman:** chance to teleport forward and gain Speed.
- **Blaze:** sets targets on fire and may grant Fire Resistance.

All sword identity is stored in item metadata, so renaming a normal sword won't grant abilities.
