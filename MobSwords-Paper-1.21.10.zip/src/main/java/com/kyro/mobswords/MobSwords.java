package com.kyro.mobswords;

import java.util.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;

public final class MobSwords extends JavaPlugin implements Listener, CommandExecutor {
    private NamespacedKey swordKey;
    private final Random random = new Random();

    private enum SwordType {
        CREEPER("Creeper Sword", ChatColor.GREEN, "Chance to cause a harmless-to-blocks blast"),
        ZOMBIE("Zombie Sword", ChatColor.DARK_GREEN, "Can weaken targets; heals you on kills"),
        SKELETON("Skeleton Sword", ChatColor.GRAY, "Can slow targets and deal bonus damage"),
        ENDERMAN("Enderman Sword", ChatColor.DARK_PURPLE, "Can teleport you and grant Speed"),
        BLAZE("Blaze Sword", ChatColor.GOLD, "Burns targets and can grant Fire Resistance");

        final String display;
        final ChatColor color;
        final String description;
        SwordType(String display, ChatColor color, String description) {
            this.display = display; this.color = color; this.description = description;
        }
        static SwordType parse(String s) {
            try { return valueOf(s.toUpperCase(Locale.ROOT)); } catch (Exception e) { return null; }
        }
    }

    @Override public void onEnable() {
        swordKey = new NamespacedKey(this, "mob_sword");
        Objects.requireNonNull(getCommand("mobsword")).setExecutor(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("MobSwords enabled!");
    }

    private ItemStack makeSword(SwordType type) {
        ItemStack item = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(type.color + "" + ChatColor.BOLD + type.display);
        meta.setLore(Arrays.asList(ChatColor.GRAY + "A netherite sword infused with mob power.",
                ChatColor.WHITE + type.description, ChatColor.DARK_GRAY + "MobSwords"));
        meta.getPersistentDataContainer().set(swordKey, PersistentDataType.STRING, type.name());
        item.setItemMeta(meta);
        return item;
    }

    private SwordType getSword(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        String value = item.getItemMeta().getPersistentDataContainer().get(swordKey, PersistentDataType.STRING);
        return value == null ? null : SwordType.parse(value);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("list")) {
            sender.sendMessage(ChatColor.GOLD + "Mob Swords: " + ChatColor.GREEN +
                    "creeper, zombie, skeleton, enderman, blaze");
            return true;
        }
        if (!sender.hasPermission("mobswords.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to use this command.");
            return true;
        }
        if (args.length != 3 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /mobsword give <player> <creeper|zombie|skeleton|enderman|blaze>");
            sender.sendMessage(ChatColor.YELLOW + "Use /mobsword list to see sword types.");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "That player must be online.");
            return true;
        }
        SwordType type = SwordType.parse(args[2]);
        if (type == null) {
            sender.sendMessage(ChatColor.RED + "Unknown sword type. Use /mobsword list.");
            return true;
        }
        HashMap<Integer, ItemStack> leftovers = target.getInventory().addItem(makeSword(type));
        leftovers.values().forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
        sender.sendMessage(ChatColor.GREEN + "Gave " + type.display + " to " + target.getName() + ".");
        target.sendMessage(ChatColor.GREEN + "You received " + type.color + type.display + ChatColor.GREEN + "!");
        return true;
    }

    @EventHandler public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        SwordType type = getSword(player.getInventory().getItemInMainHand());
        if (type == null) return;
        Entity target = event.getEntity();
        switch (type) {
            case CREEPER -> {
                if (random.nextDouble() < 0.20) {
                    target.getWorld().playSound(target.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.1f);
                    target.getWorld().spawnParticle(Particle.EXPLOSION, target.getLocation().add(0, 0.7, 0), 1);
                    for (Entity nearby : target.getNearbyEntities(2.5, 2.0, 2.5)) {
                        if (nearby instanceof LivingEntity living && nearby != player && nearby != target)
                            living.damage(3.0, player);
                    }
                    target.damage(3.0, player);
                    player.sendMessage(ChatColor.GREEN + "Creeper burst!");
                }
            }
            case ZOMBIE -> {
                if (random.nextDouble() < 0.25 && target instanceof LivingEntity living) {
                    living.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0));
                    living.addPotionEffect(new PotionEffect(PotionEffectType.HUNGER, 80, 0));
                    player.playSound(player.getLocation(), Sound.ENTITY_ZOMBIE_AMBIENT, 0.5f, 1.5f);
                }
            }
            case SKELETON -> {
                if (random.nextDouble() < 0.25 && target instanceof LivingEntity living) {
                    event.setDamage(event.getDamage() + 3.0);
                    living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50, 0));
                    living.getWorld().spawnParticle(Particle.CRIT, living.getLocation().add(0, 1, 0), 8, 0.3, 0.4, 0.3, 0.1);
                }
            }
            case ENDERMAN -> {
                if (random.nextDouble() < 0.15) {
                    Location destination = player.getLocation().clone().add(player.getLocation().getDirection().multiply(3));
                    destination.setY(player.getLocation().getY());
                    destination.setYaw(player.getLocation().getYaw());
                    destination.setPitch(player.getLocation().getPitch());
                    if (destination.getBlock().isPassable() && destination.clone().add(0, 1, 0).getBlock().isPassable()) {
                        player.teleport(destination);
                        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 80, 0));
                        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.8f, 1.2f);
                    }
                }
            }
            case BLAZE -> {
                if (target instanceof LivingEntity living) {
                    living.setFireTicks(Math.max(living.getFireTicks(), 60));
                    if (random.nextDouble() < 0.15) {
                        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 100, 0));
                        player.getWorld().spawnParticle(Particle.FLAME, player.getLocation().add(0, 1, 0), 12, 0.4, 0.5, 0.4, 0.02);
                    }
                }
            }
        }
    }

    @EventHandler public void onMobDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null || getSword(killer.getInventory().getItemInMainHand()) != SwordType.ZOMBIE) return;
        if (killer.getHealth() < 20.0) killer.setHealth(Math.min(20.0, killer.getHealth() + 2.0));
        killer.getWorld().spawnParticle(Particle.HEART, killer.getLocation().add(0, 1.5, 0), 3, 0.3, 0.3, 0.3);
    }
}
